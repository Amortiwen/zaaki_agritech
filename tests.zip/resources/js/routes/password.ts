export const edit = () => '/user/profile';
export const request = () => '/forgot-password';
export const confirm = {
    store: () => '/user/confirm-password',
};
