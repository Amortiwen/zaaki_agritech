export const edit = () => '/user/profile';
