// Simple route helpers to replace wayfinder-generated routes

export const dashboard = () => '/dashboard';
export const home = () => '/';
export const login = () => '/login';
export const register = () => '/register';
export const logout = () => '/logout';

// Password routes
export const password = {
    request: () => '/forgot-password',
    confirm: {
        store: () => '/user/confirm-password',
    },
};

// Profile routes  
export const profile = {
    edit: () => '/user/profile',
};

// Two factor routes
export const twoFactor = {
    show: () => '/user/two-factor-authentication',
    enable: () => '/user/two-factor-authentication',
    disable: () => '/user/two-factor-authentication',
    qrCode: () => '/user/two-factor-qr-code',
    recoveryCodes: () => '/user/two-factor-recovery-codes',
    secretKey: () => '/user/two-factor-secret-key',
    confirm: () => '/user/confirmed-two-factor-authentication',
    login: {
        store: () => '/two-factor-challenge',
    },
    regenerateRecoveryCodes: () => '/user/two-factor-recovery-codes',
};

// Verification routes
export const verification = {
    send: () => '/email/verification-notification',
};

// Appearance routes
export const appearance = {
    edit: () => '/user/profile',
};
