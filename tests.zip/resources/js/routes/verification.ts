export const send = () => '/email/verification-notification';
