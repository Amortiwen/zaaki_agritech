import { router } from '@inertiajs/react'

export default {
    store: {
        form: () => ({
            data: {
                token: '',
                email: '',
                password: '',
                password_confirmation: '',
            },
            errors: {},
            processing: false,
            transform: (data: any) => data,
            submit: (method: string, url: string, options: any) => {
                return router.post(url, data, {
                    ...options,
                    onStart: () => {
                        processing = true
                    },
                    onFinish: () => {
                        processing = false
                    },
                    onError: (errors: any) => {
                        errors = errors
                    },
                })
            },
        }),
    },
}
