import MainController from './MainController'
import Auth from './Auth'

const Controllers = {
    MainController: Object.assign(MainController, MainController),
    Auth: Object.assign(Auth, Auth),
}

export default Controllers